package com.empanada.model;

import java.sql.Date;
import java.util.List;

public class GetOrderNumberBranchInfo {
	   private long lONid;
	   private long lOrder_Number;
	   private long lBid;
	   private Date dDateOrdered;
	   private String strStatus;
	   private String strRemarks;
	   private List<BranchUser> branchuser;
	   
	public GetOrderNumberBranchInfo(long lONid, long lOrder_Number, long lBid,
			Date dDateOrdered, String strStatus, String strRemarks,
			List<BranchUser> branchuser) {
		super();
		this.lONid = lONid;
		this.lOrder_Number = lOrder_Number;
		this.lBid = lBid;
		this.dDateOrdered = dDateOrdered;
		this.strStatus = strStatus;
		this.strRemarks = strRemarks;
		this.branchuser = branchuser;
	}

	public long getlONid() {
		return lONid;
	}

	public void setlONid(long lONid) {
		this.lONid = lONid;
	}

	public long getlOrder_Number() {
		return lOrder_Number;
	}

	public void setlOrder_Number(long lOrder_Number) {
		this.lOrder_Number = lOrder_Number;
	}

	public long getlBid() {
		return lBid;
	}

	public void setlBid(long lBid) {
		this.lBid = lBid;
	}

	public Date getdDateOrdered() {
		return dDateOrdered;
	}

	public void setdDateOrdered(Date dDateOrdered) {
		this.dDateOrdered = dDateOrdered;
	}

	public String getStrStatus() {
		return strStatus;
	}

	public void setStrStatus(String strStatus) {
		this.strStatus = strStatus;
	}

	public String getStrRemarks() {
		return strRemarks;
	}

	public void setStrRemarks(String strRemarks) {
		this.strRemarks = strRemarks;
	}

	public List<BranchUser> getBranchuser() {
		return branchuser;
	}

	public void setBranchuser(List<BranchUser> branchuser) {
		this.branchuser = branchuser;
	}
	   
	   
	   

}
