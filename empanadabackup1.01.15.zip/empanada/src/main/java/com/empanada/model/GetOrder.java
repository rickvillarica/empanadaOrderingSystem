package com.empanada.model;

import java.util.List;

public class GetOrder {
	   private long lOrder_Number;
	   private long lIid;
       private int quantity;
       private List<Item> Items;
       
       
       
     public GetOrder(long lOrder_Number, long lIid, int quantity, List<Item> items) {
		super();
		this.lOrder_Number = lOrder_Number;
		this.lIid = lIid;
		this.quantity = quantity;
		Items = items;
	}




	public long getlOrder_Number() {
		return lOrder_Number;
	}



	public void setlOrder_Number(long lOrder_Number) {
		this.lOrder_Number = lOrder_Number;
	}



	public long getlIid() {
		return lIid;
	}



	public void setlIid(long lIid) {
		this.lIid = lIid;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public List<Item> getItems() {
		return Items;
	}



	public void setItems(List<Item> items) {
		Items = items;
	}



	
    

}
