package com.empanada.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orderItem")
public class OrderItem {
	   private long lOid;
	   private long lOrder_Number;
	   private long lIid;
       private int quantity;
     
       public List<Item> Items;      
       
       

//   	public OrderItem(long lOid, String item, int quantity) {
//		super();
//		this.lOid = lOid;
//		this.item = item;
//		this.quantity = quantity;
//	}

//    @Column(nullable = false)   
//	public List<Item> getItems() {
//		return Items;
//	}


	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)       
    public long getlOid() {
		return lOid;
	}
   	

	public void setlOid(long lOid) {
		this.lOid = lOid;
	}
   	
	@Column(nullable = false)
	public long getlIid() {
		return lIid;
	}


	public void setlIid(long lIid) {
		this.lIid = lIid;
	}


	@Column(nullable = false)
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Column(nullable = false)
	public long getlOrder_Number() {
		return lOrder_Number;
	}


	public void setlOrder_Number(long lOrder_Number) {
		this.lOrder_Number = lOrder_Number;
	}

//	 Item item;
//	    
//	 @OneToMany //correct mapping here
//	 public Item getItems(){
//		 return this.item;
//	}
	       
}