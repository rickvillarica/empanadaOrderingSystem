package com.empanada.model;

public class AdminLogin {
	
	private long lAid;
	private String strUserName;
    private String strFirstName;
    private String strLastName;
    private String strPassword;
    
    
    public AdminLogin(){
		super();
	}
    
	public AdminLogin(long lAid, String strUserName, String strFirstName,
			String strLastName) {
		super();
		this.lAid = lAid;
		this.strUserName = strUserName;
		this.strFirstName = strFirstName;
		this.strLastName = strLastName;
	}

	public long getlAid() {
		return lAid;
	}

	public String getStrUserName() {
		return strUserName;
	}

	public String getStrFirstName() {
		return strFirstName;
	}

	public String getStrLastName() {
		return strLastName;
	}

	public String getStrPassword() {
		return strPassword;
	}
    
    

}
