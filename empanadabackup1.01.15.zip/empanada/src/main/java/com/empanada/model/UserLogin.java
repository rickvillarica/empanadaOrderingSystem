package com.empanada.model;

public class UserLogin {
	private long lBid;	
    private String strBranchName;
    private String strPassword;
    private String strOwner;
    private String strAddress;
    
    public UserLogin(){
		super();
	}
    
	public UserLogin(long lBid, String strBranchName,
			String strOwner, String strAddress) {
		super();
		this.lBid = lBid;
		this.strBranchName = strBranchName;
		this.strOwner = strOwner;
		this.strAddress = strAddress;
	}


	

	public long getlBid() {
		return lBid;
	}


	public String getStrBranchName() {
		return strBranchName;
	}


	public String getStrPassword() {
		return strPassword;
	}


	public String getStrOwner() {
		return strOwner;
	}


	public String getStrAddress() {
		return strAddress;
	}
	
	
	
}
