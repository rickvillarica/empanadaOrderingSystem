//package com.empanada.model;
//
//public class GetItems {
//	 private long lIid;	
//     private String strName;
//     private String strType;
//     private float fPrice;
//     
//     
//	public GetItems(long lIid, String strName, String strType, float fPrice) {
//		super();
//		this.lIid = lIid;
//		this.strName = strName;
//		this.strType = strType;
//		this.fPrice = fPrice;
//	}
//
//
//	public long getlIid() {
//		return lIid;
//	}
//
//
//	public void setlIid(long lIid) {
//		this.lIid = lIid;
//	}
//
//
//	public String getStrName() {
//		return strName;
//	}
//
//
//	public void setStrName(String strName) {
//		this.strName = strName;
//	}
//
//
//	public String getStrType() {
//		return strType;
//	}
//
//
//	public void setStrType(String strType) {
//		this.strType = strType;
//	}
//
//
//	public float getfPrice() {
//		return fPrice;
//	}
//
//
//	public void setfPrice(float fPrice) {
//		this.fPrice = fPrice;
//	}
//   
//	
//     
//
//}
