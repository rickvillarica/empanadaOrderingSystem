package com.empanada.service;

import java.util.List;

import com.empanada.model.AdminUser;
import com.empanada.model.BranchUser;
import com.empanada.model.Item;
import com.empanada.model.OrderItem;
import com.empanada.model.OrderNumber;

public interface MainService {

       
       public void saveItem(Item item);
       public void saveBranchUser(BranchUser branchuser);
       public void saveAdminUser(AdminUser adminuser);	
       public void saveOrderItem(OrderItem orderItem);
       public void saveOrderNumber(OrderNumber num);
       
       
       public List<Item> listItems();
       public List<BranchUser> listBranchUsers();
       public List<AdminUser> listAdminUsers();
       public List<OrderNumber> lastRecord();
       public List<OrderNumber> listOrders(long lBid);
       public List<OrderNumber> listDeliveredOrders(long lBid);
       public List<OrderNumber> getOrderNumberBranchInfo();
       public List<OrderNumber> getOrderNumberBranchInfoDelivered();
       
       public Item getItem(long lIid);
       public BranchUser getBranchUser(long lBid);
       public AdminUser getAdminUser(long lAid);
       
       public void deleteItem(long lIid);
       public void deleteBranchUser(long lBid);
       public void deleteAdminUser(long lAid);
       public void deleteOrderAndItem(long lOrder_Number);
       
       public List<BranchUser> checkLogin(long branchID, String name, String password);
       public List<AdminUser> checkAdminLogin(String name, String password);
       public List<OrderItem> getOrderedItems(long lOrder_Number);
       
       public void approveOrder(String remark, long lOrder_Number);
       public void disapproveOrder(String remark, long lOrder_Number);
       public void reportDelivery(long lOrder_Number);

}