package com.empanada.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.empanada.dao.MainDao;
import com.empanada.model.AdminUser;
import com.empanada.model.BranchUser;
import com.empanada.model.Item;
import com.empanada.model.OrderItem;
import com.empanada.model.OrderNumber;
import com.empanada.service.MainService;

@Service
public class MainServiceImpl implements MainService {

       @Autowired
       private MainDao mainDao;

       @Transactional
       public void saveItem(Item item) {
    	   mainDao.saveItem(item);
       }
       
       @Transactional
       public void saveBranchUser(BranchUser branchuser){
    	   mainDao.saveBranchUser(branchuser);
       }
       
       @Transactional
       public void saveAdminUser(AdminUser adminuser){
    	   mainDao.saveAdminUser(adminuser);
       }

       @Transactional
       public void saveOrderItem(OrderItem orderItem){
		   mainDao.saveOrderItem(orderItem);
	   }
       
       @Transactional
       public void saveOrderNumber(OrderNumber num){
		   mainDao.saveOrderNumber(num);
	   }
       
       @Transactional( readOnly = true)
       public List<Item> listItems() {
              return mainDao.listItems();
       }
       
       @Transactional( readOnly = true)
       public List<BranchUser> listBranchUsers(){
    	   return mainDao.listBranchUsers();
    	   
       }
       
       @Transactional( readOnly = true)
       public List<AdminUser> listAdminUsers(){
    	   return mainDao.listAdminUsers();
    	   
       }
       
       @Transactional
       public List<OrderNumber> lastRecord(){
    	   return mainDao.lastRecord();
    	   
       }
       
       @Transactional
       public List<OrderNumber> listOrders(long lBid){
    	   return mainDao.listOrders(lBid);
    	   
       }

       @Transactional
       public List<OrderNumber> listDeliveredOrders(long lBid){
    	   return mainDao.listDeliveredOrders(lBid);
    	   
       }
       
       @Transactional( readOnly = true)
       public Item getItem(long lIid) {
              return mainDao.getItem(lIid);
       }

       @Transactional( readOnly = true)
       public BranchUser getBranchUser(long lBid){
           return mainDao.getBranchUser(lBid);
       }
       
       @Transactional( readOnly = true)
       public AdminUser getAdminUser(long lAid){
           return mainDao.getAdminUser(lAid);
       }
       
       
       @Transactional
       public void deleteItem(long lIid) {
    	   mainDao.deleteItem(lIid);

       }
       
       @Transactional
       public void deleteBranchUser(long lBid) {
    	   mainDao.deleteBranchUser(lBid);

       }
       
       @Transactional
       public void deleteAdminUser(long lAid) {
    	   mainDao.deleteAdminUser(lAid);

       }
       
       @Transactional
       public void deleteOrderAndItem(long lOrder_Number){
    	   mainDao.deleteOrderAndItem(lOrder_Number);

       }
       
       @Transactional
       public List<BranchUser> checkLogin(long branchID, String name, String password){
    	   return mainDao.checkLogin(branchID, name, password);

       }
       
       @Transactional
       public List<AdminUser> checkAdminLogin(String name, String password){
    	   return mainDao.checkAdminLogin(name, password);

       };
       
       @Transactional
       public List<OrderItem> getOrderedItems(long lOrder_Number){
    	   return mainDao.getOrderedItems(lOrder_Number);

       };
       
       @Transactional
       public List<OrderNumber> getOrderNumberBranchInfo(){
    	   return mainDao.getOrderNumberBranchInfo();

       };
       
       @Transactional
       public List<OrderNumber> getOrderNumberBranchInfoDelivered(){
    	   return mainDao.getOrderNumberBranchInfoDelivered();

       };
       
       @Transactional
       public void approveOrder(String remark, long lOrder_Number){
    	   mainDao.approveOrder(remark,lOrder_Number);

       };
       
       @Transactional
       public void disapproveOrder(String remark, long lOrder_Number){
    	   mainDao.disapproveOrder(remark,lOrder_Number);

       };
       
       @Transactional
       public void reportDelivery(long lOrder_Number){
    	   mainDao.reportDelivery(lOrder_Number);

       };
}
