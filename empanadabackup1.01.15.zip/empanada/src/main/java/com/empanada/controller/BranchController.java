package com.empanada.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.empanada.model.BranchUser;
import com.empanada.model.GetOrder;
import com.empanada.model.Item;
import com.empanada.model.OrderItem;
import com.empanada.model.OrderNumber;
import com.empanada.model.UserLogin;
import com.empanada.service.MainService;

@Controller
@RequestMapping("/branch")
public class BranchController {
	
	
	 @Autowired
     private MainService mainservice;
     
	 @RequestMapping(value="/loginBranch", method = RequestMethod.GET)
	 public ModelAndView login() {
			return new ModelAndView("/avenueBranch/loginBranch", "command", new UserLogin());
			
	 }
	 
	 @RequestMapping(value="/logoutBranch", method = RequestMethod.GET)
		public String endsession(HttpSession session) {
			session.invalidate();
			
			return "redirect:loginBranch"; 
			
	 }
	 
	 @RequestMapping(value="/processlogin", method = RequestMethod.POST)
	 public String processlogin(HttpSession session, ModelMap model, 
			@RequestParam(value="lBid", defaultValue="") long branchID,
			@RequestParam(value="strBranchName", defaultValue="") String name,
			@RequestParam(value="strPassword", defaultValue="") String password) {
		 
		 
		 	List<BranchUser> login = mainservice.checkLogin(branchID, name, password);
		 	
		 
			
			if(!login.isEmpty()){
				BranchUser x = login.get(0);
				UserLogin user = new UserLogin(x.getlBid(), x.getStrBranchName(), x.getStrOwner(), x.getStrAddress());
			
				session.setAttribute("user", user);
				//model.addAttribute("user", user);
				return "redirect:branchHome";
			}else{
				return "redirect:loginBranch";
			}

	}
	 
     @RequestMapping(value = { "/", "/branchHome" })
     public String mainHome(HttpSession session) {
    	 
    	 if(session.getAttribute("user")==null){
				return "redirect:loginBranch";
		 }else
		 {
		 		return "/avenueBranch/BranchHome";
		 }
     }
     
     
     @RequestMapping(value = { "/", "/listOrders" })
     public String listOrders(Map<String, Object> map, HttpSession session) {
    	 if(session.getAttribute("user")==null){
				return "redirect:loginBranch";
	 	 }else
	 	 {
           // map.put("item", new Item());
    	 	UserLogin user = (UserLogin) session.getAttribute("user");
    	 
    	 	map.put("user", user);
    	 	
            map.put("orderList", mainservice.listOrders(user.getlBid()));

            return "/avenueBranch/listOrders";
	 	 }
     }
     
     @RequestMapping(value = { "/", "/listDeliveredOrders" })
     public String listDeliverdOrders(Map<String, Object> map, HttpSession session) {
    	 if(session.getAttribute("user")==null){
				return "redirect:loginBranch";
	 	 }else
	 	 {
           // map.put("item", new Item());
    	 	UserLogin user = (UserLogin) session.getAttribute("user");
    	 
    	 	map.put("user", user);
    	 	
            map.put("orderList", mainservice.listDeliveredOrders(user.getlBid()));

            return "/avenueBranch/listDeliveredOrders";
	 	 }
     }

     @RequestMapping(value = { "/", "/showItems" })
     public String listBooks(Map<String, Object> map, HttpSession session) {
    	 
    	 if(session.getAttribute("user")==null){
				return "redirect:loginBranch";
    	 }else
    	 {

	            map.put("itemList", mainservice.listItems());
	
	            return "/avenueBranch/showItems";
		}
     }
     
     @RequestMapping(value = { "/", "/orderForm" })
     public String orderForm(Map<String, Object> map, HttpSession session) {
    	 if(session.getAttribute("user")==null){
				return "redirect:loginBranch";
	 	 }else
	 	 {
	    	UserLogin user = (UserLogin) session.getAttribute("user");
    	 	
	         
	        map.put("lastOrderNumber", mainservice.lastRecord());
         
            map.put("user", user);

            map.put("itemList", mainservice.listItems());

            return "/avenueBranch/branchOrderForm";
	 	 }
     }
     

     @RequestMapping(value="/saveOrderItem", method = RequestMethod.POST)
     public String saveOrderItem( HttpServletRequest req) {
    	 long branchID = Long.parseLong(req.getParameter("lBid"));
    	 long orderNumber = Long.parseLong(req.getParameter("lOrder_Number"));
    	 String [] item = req.getParameterValues("item");
    	 String [] qty = req.getParameterValues("quantity");
    	 
    	 OrderItem order = new OrderItem();
    	 
    	 for (int i=0; i<item.length; i++){ 
    		 order.setlOrder_Number(orderNumber);
	         order.setlIid(Long.parseLong(item[i]));
	         order.setQuantity(Integer.parseInt(qty[i]));
	         
	         mainservice.saveOrderItem(order);
    	 }
    	
    	 java.util.Date utilDate = new java.util.Date();
    	 java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
    	    
    	    
    	 OrderNumber num = new OrderNumber();
    	 num.setlBid(branchID);
    	 num.setlOrder_Number(orderNumber);
    	 num.setdDateOrdered(sqlDate);
    	 num.setStrStatus("For Approval");
    	// num.setStrRemarks("waiting for response from Main Branch");
    	 mainservice.saveOrderNumber(num);
    	 
 			return "redirect:listOrders";
 	}
     
     @RequestMapping("/getItemsOrdered/{lOrder_Number}")
     public String getBook(@PathVariable long lOrder_Number, Map<String, Object> map,HttpSession session) {
    	 if(session.getAttribute("user")==null){
				return "redirect:loginBranch";
	 	 }else
	 	 {
	    	UserLogin user = (UserLogin) session.getAttribute("user");
 	 	
	    	map.put("user", user);
	    	
    	 	
	    	List<OrderItem> orders = mainservice.getOrderedItems(lOrder_Number);
	    	List<GetOrder> getorders = new ArrayList<GetOrder>();
	    //	List<GetItems> items =new ArrayList<GetItems>();
	        for (int i=0; i<orders.size(); i++){
	        	
//	        	for (int j=0; j<orders.get(i).Items.size(); j++){
//	        	//System.out.println(orders.get(i).Items.get(j).getStrName() +"  "+   orders.get(i).Items.get(j).getfPrice());
//	        		GetItems getitem=new GetItems(orders.get(i).Items.get(j).getlIid(), orders.get(i).Items.get(j).getStrName(), orders.get(i).Items.get(j).getStrType(), orders.get(i).Items.get(j).getfPrice() );
//	        		items.add(getitem);
//	        	
//	        	}
	        	GetOrder getorder =new GetOrder(orders.get(i).getlOrder_Number(),orders.get(i).getlIid(), orders.get(i).getQuantity(),orders.get(i).Items );
	        	getorders.add(getorder);
	        
	        }
		    	
            map.put("orderedItemsList", getorders);
            
            return "/avenueBranch/displaybranchOrder";
	 	 }
     }

     
     @RequestMapping("/deleteOrder/{lOrder_Number}")
     public String deleteOrder(@PathVariable("lOrder_Number")long lOrder_Number) {

            mainservice.deleteOrderAndItem(lOrder_Number);
            
            return "redirect:/branch/listOrders";
     }
     
     
     
     @RequestMapping("/orderDelivered/{lOrder_Number}")
     public String reportDelivery(@PathVariable("lOrder_Number")long lOrder_Number) {

            mainservice.reportDelivery(lOrder_Number);

            return "redirect:/branch/listOrders";
     }
     
     
}
