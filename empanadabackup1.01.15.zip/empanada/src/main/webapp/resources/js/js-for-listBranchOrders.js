function approveOrder(lOrder_Number) {
	$('#orderID').val(lOrder_Number);
	$('#remarkDialog').dialog("option", "title", 'Approve Order');
	$('#remarkDialog').dialog('open');
}

function disapproveOrder(lOrder_Number) {
	$('#orderIDDisapprove').val(lOrder_Number);
	$('#remarkDialogDisapprove').dialog("option", "title", 'Disapprove Order');
	$('#remarkDialogDisapprove').dialog('open');
}

function showItems(lOrder_Number, branchid, branchname, address) {

	$.get("getItemsOrderedMain/" + lOrder_Number + "="+branchid+"="+branchname+"="+address, function(result) {

	
		$("#itemDialog").html(result);

		$("#itemDialog").dialog("option", "title", 'View Items Ordered');

		$("#itemDialog").dialog('open');
		

	
	});
}


function resetDialog(form) {

	form.find("input").val("");
}


$(document).ready(function() {

	$('#itemDialog').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 780,
		buttons : {
			
			"Back" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#displaybranchOrder'));

			$(this).dialog('close');
		}
	});


});



$(document).ready(function() {

	$('#remarkDialog').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 500,
		buttons : {
			"Submit" : function() {
				$('#remarksForm').submit();
			},
			"Cancel" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#remarksForm'));

			$(this).dialog('close');
		}
	});


});

$(document).ready(function() {

	$('#remarkDialogDisapprove').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 500,
		buttons : {
			"Submit" : function() {
				$('#remarksFormDisapprove').submit();
			},
			"Cancel" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#remarksFormDisapprove'));

			$(this).dialog('close');
		}
	});


});

