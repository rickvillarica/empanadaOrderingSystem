function addItem() {
	$('#itemDialog').dialog("option", "title", 'Add Item');
	$('#itemDialog').dialog('open');
}

function editItem(lIid) {

	$.get("getItem/" + lIid, function(result) {

		$("#itemDialog").html(result);

		$("#itemDialog").dialog("option", "title", 'Edit Item');

		$("#itemDialog").dialog('open');

	
	});
}



function resetDialog(form) {

	form.find("input").val("");
}

$(document).ready(function() {

	$('#itemDialog').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 260,
		buttons : {
			"Save" : function() {
				$('#itemForm').submit();
			},
			"Cancel" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#itemForm'));

			$(this).dialog('close');
		}
	});


});
