function addAdminUser() {
	$('#adminUserDialog').dialog("option", "title", 'Add Admin User ');
	$('#adminUserDialog').dialog('open');
}

function editAdminUser(lAid) {

	$.get("getAdminUser/" + lAid, function(result) {

		$("#adminUserDialog").html(result);

		$("#adminUserDialog").dialog("option", "title", 'Edit Admin User');

		$("#adminUserDialog").dialog('open');

	
	});
}



function resetDialog(form) {

	form.find("input").val("");
}

$(document).ready(function() {

	$('#adminUserDialog').dialog({

		autoOpen : false,
		position : 'center',
		modal : true,
		resizable : false,
		width : 300,
		buttons : {
			"Save" : function() {
				$('#adminUserForm').submit();
			},
			"Cancel" : function() {
				$(this).dialog('close');
			}
		},
		close : function() {

			resetDialog($('#adminUserForm'));

			$(this).dialog('close');
		}
	});


});
